﻿<?php
require_once('config.php');

$tpl_vars=array();
$tpl_file='index.tmpl';
require_once('tpl_config.php');
?>
<?php
require_once('config.php');

$tpl_vars=array();
$tpl_file='lab1-2.tmpl';
require_once('tpl_config.php');
?>